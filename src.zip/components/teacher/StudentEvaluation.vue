<template>
</template>

<script>
export default {
  data() {
    return {
      studentData: [{
        _id: '10352',
        name: 'dale',
        topic: {
          name: 'lalaland'
        }
      }]
    }
  }
}

</script>