<style lang="sass" rel="stylesheet/scss">
	@import "../../style/main";
</style>