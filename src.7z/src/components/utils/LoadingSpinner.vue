<template>
	<md-spinner :md-size="150" 
							md-indeterminate 
							class="md-accent">
	</md-spinner>
</template>