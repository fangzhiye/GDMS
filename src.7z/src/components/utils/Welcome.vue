<template>
<div class="main-content">
		<p>
			欢迎使用毕业设计管理系统
		</p>
</div>

</template>