<template>
	<div class="not-found">
		<div class="background">
		</div>
	</div>
</template>

<style type="text/css" media="screen">
	.not-found{
		background-color: #868686;
	}
	.background{
		width: 100%;
		height: 100vh;
		background: url('../../assets/img/404.jpg') no-repeat;
		background-position: center;
	}
</style>