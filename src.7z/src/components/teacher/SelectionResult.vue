<template>
  <div class="result-container" v-if="gotResult">
    <div class="sub-padding">
      <div class="teacher-topics-status">
          <div class="single-card" v-for="(result,index) in _tch_StudentConfirmed">
            <div class="paper">
              <div class="result-title">
                {{result._id}}. {{result.title}}
              </div>
              <ul>
                <li class="student-list" v-for="(student,sid) in  result.finalstudents">
                  <div class="student-details">
                    <div class="student-name">{{student.name}} {{student._id}}</div>
                    <div class="student-contact">
                        <img src="../../assets/icon/call.svg" alt="QQ" />
                        <span> {{student.tel}}</span>
                        <img src="../../assets/icon/mail.svg" alt="QQ" />
                        <a :href="'mailto:'+student.email" class="mail-link">{{student.email}}</a>
                        <br/>
                        <img src="../../assets/icon/qq.svg" alt="QQ" /> 
                        <span>{{student.qq}}</span>
                        <img src="../../assets/icon/wechat.svg" alt="WECHAT" />
                        <span>{{student.wechat}}</span> 
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
      </div>
    </div>
  </div>
  <div class="main-content" v-else>
    <div class="empty-card-title" :class="{'hide':open}">
      这里空空如也！
      <p class="intrgging">不是说了啥都没有么 (゜-゜)つロ。</p>
    </div>
  </div>
</template>


<script>
import { mapState, mapActions } from 'vuex'
export default {
  data() {
      return {
        gotResult: true,
      }
    },
    computed: mapState(['_tch_StudentConfirmed']),
    methods: {
      ...mapActions(['tchSelectionResult'])
      //一键导出excel表格功能实现
    },
    mounted() {
      let id = _c.getCookie('user')
      if (id) {
        this.tchSelectionResult({ teacherId: user })
      } else {
        //this.$router.push('/')
      }
    }
}

</script>

<style lang="sass" rel="stylesheet/scss">
@import '../../style/variables.scss';


.teacher-topics-status
{
        display: flex;
        justify-content: space-between;
    margin: 8px 0;
    .single-card
    {
        margin: 8px 0;
        width: 480px;
        .paper{
          padding: 0;
        }
        .result-title
        {
            padding: 8px;

            color: #fff;
            border-top-left-radius: 2px;
            border-top-right-radius: 2px;
            background-color: $indigo400 ;
        }

            .student-list{

            }
            .student-details
            {
                font-size: 16px;

                overflow: hidden;
                padding: 8px;

                cursor: default;
                transition: $material-enter;
                .student-name
                {
                    display: inline-block;

                    height: 32px;
                    margin-left: 18px;

                    vertical-align: middle;
                }
                .mail-link{
                  color: rgba(0,0,0,.7) !important;
                  &:hover{
                    text-decoration: none !important;
                  }
                }
              }
    }
}

</style>